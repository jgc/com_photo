DROP TABLE IF EXISTS `#__photo`;
